# 服饰中心创意供给监控看板 · 接手人指南

> 本工具由傻福🦞封装，复制本目录到你的工作区即可使用。

---

## 📦 包含文件

| 文件 | 用途 |
|---|---|
| `README.md` | 本指南 |
| `服饰创意供给监控看板.md` | CodeBuddy Skill 文件（放到 skills 目录） |
| `update_dashboard.py` | 看板更新主脚本（自带兼容逻辑） |
| `config.example.txt` | 配置示例文件 |
| `index.html` | 看板主文件（接手时由 Javi 一并提供） |
| `竞价KA客户名单.xlsx` | KA 白名单（接手时由 Javi 一并提供） |

---

## 🛠️ 一次性环境搭建（约 15 分钟）

### Step 1 · 安装基础环境

- macOS 或 Linux 系统（Windows 也可，但路径需要自行调整）
- Python 3.8+（一般系统自带）
- 安装唯一依赖：
  ```bash
  pip3 install openpyxl
  ```

### Step 2 · 安装并打开 CodeBuddy

下载地址：https://www.codebuddy.ai/

### Step 3 · 把本目录放到你的工作区

建议路径示例：
```
~/Desktop/服饰看板更新工具/
├── README.md
├── 服饰创意供给监控看板.md
├── update_dashboard.py
├── config.txt          ← 自己根据 config.example.txt 创建
├── index.html          ← Javi 提供
├── 竞价KA客户名单.xlsx  ← Javi 提供
└── 日报源数据/         ← 每日下载的 CSV 放这里
```

### Step 4 · 创建 `config.txt`

参考 `config.example.txt`，把里面的路径改成你自己的：

```
WORKSPACE_DIR=/Users/你的用户名/Desktop/服饰看板更新工具
SRC_DIR=/Users/你的用户名/Desktop/服饰看板更新工具/日报源数据
HTML_FILE=/Users/你的用户名/Desktop/服饰看板更新工具/index.html
KA_FILE=/Users/你的用户名/Desktop/服饰看板更新工具/竞价KA客户名单.xlsx
```

### Step 5 · 安装 Skill 到 CodeBuddy

把 `服饰创意供给监控看板.md` 复制到 CodeBuddy 的 skills 目录（项目级或用户级均可）。
- 项目级：`<工作区>/.codebuddy/skills/`
- 用户级：`~/.codebuddy/skills/`

### Step 6 · 配置自己的 GitHub 仓库（用于发布看板）

1. 在自己的 GitHub 创建仓库（如 `fashion_dashboard`），启用 Pages（Settings → Pages → Source 选 main branch）
2. 在工作区目录初始化 git 并关联：
   ```bash
   cd ~/Desktop/服饰看板更新工具
   git init
   git remote add origin https://github.com/你的用户名/fashion_dashboard.git
   git branch -M main
   ```
3. 首次推送：
   ```bash
   cp index.html index.html  # 已经有了，直接push
   git add index.html
   git commit -m "init: 初始化看板"
   git push -u origin main
   ```
4. 发布地址：`https://你的用户名.github.io/fashion_dashboard/`

---

## 📅 每日工作流（5-10 分钟）

### Step 1 · 下载 9 张 CSV + 1 张 xlsx

每天上午从数据平台下载以下 9 张 CSV，放到 `日报源数据/` 目录：

| # | 文件命名规则（MMDD = 当日日期，如 0506） |
|---|---|
| ① | `分行业MMDD.csv` |
| ② | `分行业周同比MMDD.csv` |
| ③ | `分链路MMDD.csv` |
| ④ | `分链路周同比MMDD.csv` |
| ⑤ | `九图MMDD.csv`（或 `朋友圈九图MMDD.csv`） |
| ⑥ | `九图周同比MMDD.csv` |
| ⑦ | `视频号MMDD.csv`（或 `视频号流量MMDD.csv`） |
| ⑧ | `视频号周同比MMDD.csv`（或 `视频号流量周同比MMDD.csv`） |
| ⑨ | `红黑榜MMDD.csv` |

> ⚠️ **重要 · 平台缓存陷阱**：下载前先 F5 强制刷新页面，避免拿到旧缓存数据。
> ⚠️ **数据日期**：表格里的数据是 t-1（前一天）的，例如 `0506.csv` 文件 → 实际数据日期是 05-05。

### Step 2 · 让 CodeBuddy 自动更新看板

打开 CodeBuddy，对话框输入：
```
更新 0506 数据
```
（把 0506 换成你今天下载的文件日期）

CodeBuddy 会自动：
- 触发 `服饰创意供给监控看板` skill
- 调用 `update_dashboard.py` 跑数据
- 写入 `index.html`
- 输出预警与摘要

### Step 3 · 手动运行（备用方案，不依赖 AI）

如果不想用 CodeBuddy，可以直接命令行跑：

```bash
cd ~/Desktop/服饰看板更新工具
python3 update_dashboard.py 0506
```

### Step 4 · push 上线

```bash
git add index.html
git commit -m "update: 2026-05-05 data"
git push
```

GitHub Pages 一般 1-2 分钟自动部署，刷新 `https://你的用户名.github.io/fashion_dashboard/` 查看。

---

## 🐛 常见问题

### Q1: 文件名带不带"创意供给"前缀？
A: 都支持。脚本会自动适配 `九图0506.csv`、`朋友圈九图0506.csv`、`视频号0506.csv`、`视频号流量0506.csv` 等多种命名。

### Q2: CSV 列结构变了怎么办？
A: 脚本内置「动态定位消耗列」逻辑，会自动找到正确的列。如果还是报错，把错误信息发给 Javi 或 CodeBuddy 即可。

### Q3: 看板显示数据异常（如 -90%、奇怪数字）？
A: 大概率是某张 CSV 列结构和脚本预期不一致。先打开异常值对应的 CSV 第一行看表头，对照脚本里的"列结构注释"做对比；或直接让 CodeBuddy 修复。

### Q4: 怎么对外发？
A: push 完后，发线上链接给老板/同事就行：`https://你的用户名.github.io/fashion_dashboard/`

### Q5: 没装 CodeBuddy 也能用吗？
A: 可以。直接命令行跑 `python3 update_dashboard.py 0506` + 手动 git push，也是完整流程。

---

## 📞 移交支持

- 原作者：Javi（黄麒文）
- 看板版本：v4.5（2026-04-27 大改版）
- 文档版本：2026-05-05 移交版

如遇到无法解决的问题，可联系 Javi 或在 CodeBuddy 里描述问题让 AI 帮忙排查。

---

## 🦞 傻福的小提醒

- 默认**不push**，确认数据没问题再 push
- 数据看着不对就再下载一次（平台缓存常见）
- 看板每个数字都对老板可见，数据准确性 > 速度
